# YT Pulse
A mobile-first YouTube trend intelligence MVP: country/category charts, Pulse score, keyword bubbles, message DNA and audience-response UI.

## Run
1. Install Node.js 20+
2. Copy `.env.example` to `.env`
3. Add a YouTube Data API v3 key as `YOUTUBE_API_KEY`
4. `npm install`
5. `npm run dev`
6. Open http://localhost:5173

Without an API key the UI automatically shows demo data.

## Production build
`npm run build`

## API
- `GET /api/trending?region=KR&category=20`
- `GET /api/comments/:videoId`
- `GET /api/health`

## Important
The current Pulse/Growth/Message DNA values are an MVP heuristic/demo layer, not official YouTube metrics. For real velocity, store repeated snapshots in a database and calculate deltas. Audience-response classification should be added on top of sampled comments rather than represented as an official YouTube metric.
